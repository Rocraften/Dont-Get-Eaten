# Made by Rocraften
# Don't Get Eaten V2 (Enhanced UI & Settings) - April 10, 2025
import pygame
import random
import sys
import math
import json # For saving/loading settings

pygame.init()
pygame.mixer.init() # Initialize the mixer for sound

WIDTH, HEIGHT = 800, 600
WINDOW = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Don't Get Eaten! - Enhanced")

# --- Colors ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 120, 255)
GRAY = (128, 128, 128)
DARK_GRAY = (40, 40, 40)
GOLD = (255, 215, 0) # Yellow orb color
NEON_BLUE = (80, 200, 255) # Player color / UI Accent
LIGHT_BLUE = (100, 180, 255) # Blue orb color
# UI Colors
DIM_OVERLAY_COLOR = (0, 0, 0, 100) # Lighter dimming for background game view
PAUSE_PANEL_COLOR = (20, 20, 40, 220) # Darker, less transparent panel bg
MENU_BUTTON_BASE = (40, 40, 80)
MENU_BUTTON_HOVER = (70, 70, 120)
MENU_TEXT_COLOR = (200, 200, 200)
SETTINGS_PANEL_BG = (30, 30, 55, 230) # Slightly different settings bg
SLIDER_BAR_COLOR = (60, 60, 90)
SLIDER_HANDLE_COLOR = NEON_BLUE
TEXT_PRIMARY_COLOR = WHITE
TEXT_SECONDARY_COLOR = (180, 180, 220)
TITLE_COLOR = NEON_BLUE
SHADOW_COLOR = (20, 20, 30)


# --- Settings Variables ---
sfx_volume = 1.0 # Default volume (0.0 to 1.0)
SETTINGS_FILE = "settings.json"

# --- Load Settings ---
def load_settings():
    global sfx_volume
    try:
        with open(SETTINGS_FILE, 'r') as f:
            settings_data = json.load(f)
            # Load volume, ensuring it's a float and clamped
            vol = settings_data.get("sfx_volume", 1.0)
            if isinstance(vol, (int, float)):
                sfx_volume = float(vol)
                sfx_volume = max(0.0, min(1.0, sfx_volume))
            else:
                 sfx_volume = 1.0 # Default if type is wrong
            print(f"Loaded settings: SFX Volume = {sfx_volume:.2f}")
    except (FileNotFoundError):
        print("Settings file not found, using defaults.")
        sfx_volume = 1.0
    except (json.JSONDecodeError, TypeError) as e:
        print(f"Error reading settings file ({e}), using defaults.")
        sfx_volume = 1.0
    # Apply volume immediately after loading (or setting defaults)
    apply_volume_to_sounds()

# --- Save Settings ---
def save_settings():
    global sfx_volume # Ensure we are saving the global value
    try:
        settings_data = {"sfx_volume": sfx_volume}
        with open(SETTINGS_FILE, 'w') as f:
            json.dump(settings_data, f, indent=4)
        # print(f"Saved settings: SFX Volume = {sfx_volume:.2f}") # Optional confirmation
    except IOError as e:
        print(f"Error saving settings: {e}")

# --- Sound Loading ---
loaded_sounds = {}
def load_sound(name, filename):
    global loaded_sounds
    try:
        sound = pygame.mixer.Sound(filename)
        loaded_sounds[name] = sound
    except pygame.error as e:
        print(f"Warning: Could not load sound file '{filename}' - {e}")
        # Create a dummy sound object that does nothing but avoids errors
        class DummySound:
            def play(self): pass
            def set_volume(self, vol): pass
        loaded_sounds[name] = DummySound()

load_sound("collect_food", "assets/collect_food.mp3")
load_sound("collect_speed", "assets/collect_speed.mp3")
load_sound("collect_score", "assets/collect_score.mp3")
load_sound("game_over", "assets/game_over.mp3")
load_sound("menu_click", "assets/menu_click.mp3")
load_sound("pause", "assets/pause.mp3")
load_sound("volume_change", "assets/volume_change.mp3") # Plays when volume changes


# --- Apply Volume Function ---
def apply_volume_to_sounds():
    """Sets the current sfx_volume to all loaded sounds."""
    global sfx_volume, loaded_sounds
    # Ensure volume is clamped just in case
    sfx_volume = max(0.0, min(1.0, sfx_volume))
    for sound in loaded_sounds.values():
        sound.set_volume(sfx_volume)
    # print(f"Applied volume {sfx_volume:.2f} to sounds") # Debug

# --- Load Settings & Apply Initial Volume ---
load_settings()

# --- Game Constants & Settings ---
PLAYER_SIZE = 20
SNAKE_SIZE = 25
FOOD_SIZE = 15
ORB_SIZE = 18
ORB_SPAWN_CHANCE = 0.0018
ORB_DESPAWN_TIME = 4500
SPEED_BOOST_DURATION = 2000
SCORE_MULTIPLIER_DURATION = 5000
SPEED_BOOST_FACTOR = 1.8
SCORE_MULTIPLIER_FACTOR = 2
player_base_speed = 4
snake_base_speed = 1

# --- Game State Variables ---
# These are reset by reset_game_state()
player_x = WIDTH // 2
player_y = HEIGHT // 2
player_speed = player_base_speed
player_score = 0
snake_segments = [(100, 100)]
snake_length = 3
food_x = random.randint(50, WIDTH - 50)
food_y = random.randint(50, HEIGHT - 50)
active_orbs = []
speed_boost_active = False
speed_boost_end_time = 0
score_multiplier_active = False
score_multiplier_end_time = 0
particles = [] # Particle list needs reset too

# High score persists across games (but not sessions unless saved separately)
high_score = 0

# Overall application state
paused = False
in_menu = True
in_settings = False
settings_source = None # 'menu' or 'pause'
dragging_slider = False # For volume control

# --- Fonts ---
# Load fonts once
try:
    score_font = pygame.font.Font(None, 56)
    timer_font = pygame.font.Font(None, 24)
    menu_title_font = pygame.font.Font(None, 130)
    menu_button_font = pygame.font.Font(None, 60)
    menu_hs_font = pygame.font.Font(None, 56)
    pause_title_font = pygame.font.Font(None, 80)
    pause_button_font = pygame.font.Font(None, 50)
    settings_title_font = pygame.font.Font(None, 70)
    settings_label_font = pygame.font.Font(None, 40)
    settings_value_font = pygame.font.Font(None, 30)
    settings_back_button_font = pygame.font.Font(None, 50)
    game_over_font = pygame.font.Font(None, 120)
    game_over_score_font = pygame.font.Font(None, 72)
    continue_font = pygame.font.Font(None, 48)
except pygame.error as e:
    print(f"Fatal Error: Could not load default font. {e}")
    sys.exit() # Exit if fonts can't load


# --- UI Drawing Helpers ---

def draw_rounded_rect(surface, color, rect, radius):
    """Draws a rounded rectangle, handling alpha."""
    if len(color) == 4 and color[3] < 255: # Handle alpha
        alpha_surf = pygame.Surface(rect.size, pygame.SRCALPHA)
        alpha_color = color # Use the color tuple directly
        # Draw shape on the alpha surface
        pygame.draw.rect(alpha_surf, alpha_color, (0, radius, rect.width, rect.height - 2 * radius))
        pygame.draw.rect(alpha_surf, alpha_color, (radius, 0, rect.width - 2 * radius, rect.height))
        pygame.draw.circle(alpha_surf, alpha_color, (radius, radius), radius)
        pygame.draw.circle(alpha_surf, alpha_color, (rect.width - radius, radius), radius)
        pygame.draw.circle(alpha_surf, alpha_color, (radius, rect.height - radius), radius)
        pygame.draw.circle(alpha_surf, alpha_color, (rect.width - radius, rect.height - radius), radius)
        surface.blit(alpha_surf, rect.topleft)
    else: # Original drawing for opaque colors
        pygame.draw.rect(surface, color, rect.inflate(-radius * 2, 0), border_radius=radius)
        pygame.draw.rect(surface, color, rect.inflate(0, -radius * 2), border_radius=radius)
        pygame.draw.circle(surface, color, (rect.left + radius, rect.top + radius), radius)
        pygame.draw.circle(surface, color, (rect.right - radius, rect.top + radius), radius)
        pygame.draw.circle(surface, color, (rect.left + radius, rect.bottom - radius), radius)
        pygame.draw.circle(surface, color, (rect.right - radius, rect.bottom - radius), radius)

def draw_gradient_rect(surface, rect, start_color, end_color, vertical=True):
    """Draws a rectangle with a vertical or horizontal gradient."""
    steps = int(rect.height if vertical else rect.width) # Ensure integer
    if steps <= 0: return
    start_rgb = pygame.Color(start_color); end_rgb = pygame.Color(end_color)
    for i in range(steps):
        progress = i / max(1, steps - 1) # Avoid division by zero if steps=1
        r = int(start_rgb.r + (end_rgb.r - start_rgb.r) * progress)
        g = int(start_rgb.g + (end_rgb.g - start_rgb.g) * progress)
        b = int(start_rgb.b + (end_rgb.b - start_rgb.b) * progress)
        color = tuple(max(0, min(255, c)) for c in (r, g, b)) # Clamp color values
        if vertical:
            pygame.draw.line(surface, color, (rect.left, rect.top + i), (rect.right - 1, rect.top + i))
        else:
            pygame.draw.line(surface, color, (rect.left + i, rect.top), (rect.left + i, rect.bottom - 1))

def draw_styled_button(surface, rect, text, font, base_color, hover_color, text_color, border_color=NEON_BLUE, radius=15, shadow_offset=3, shadow_color=SHADOW_COLOR):
    """Draws a styled button. Returns True if hovered."""
    is_hovered = rect.collidepoint(pygame.mouse.get_pos())
    current_color = hover_color if is_hovered else base_color

    # Shadow
    shadow_rect = rect.copy(); shadow_rect.move_ip(shadow_offset, shadow_offset)
    draw_rounded_rect(surface, shadow_color + (150,), shadow_rect, radius) # Shadow with alpha

    # Button Background
    draw_rounded_rect(surface, current_color, rect, radius)

    # Border
    pygame.draw.rect(surface, border_color, rect, 2, border_radius=radius)

    # Text
    text_surf = font.render(text, True, text_color)
    surface.blit(text_surf, text_surf.get_rect(center=rect.center))
    return is_hovered

def draw_slider(surface, rect, value, min_val, max_val, handle_color, bar_color, handle_radius=10):
    """Draws a slider. Returns handle_rect."""
    pygame.draw.rect(surface, bar_color, rect, border_radius=int(rect.height / 2)) # Bar
    value_range = max_val - min_val
    progress = (value - min_val) / value_range if value_range != 0 else 0.5
    handle_x = rect.left + int(rect.width * progress)
    handle_y = rect.centery
    handle_rect = pygame.Rect(0, 0, handle_radius * 2, handle_radius * 2); handle_rect.center = (handle_x, handle_y)

    # Handle Shadow
    shadow_rect = handle_rect.copy(); shadow_rect.move_ip(2, 2)
    pygame.draw.circle(surface, SHADOW_COLOR + (150,), shadow_rect.center, handle_radius) # Shadow with alpha
    # Handle
    pygame.draw.circle(surface, handle_color, handle_rect.center, handle_radius)
    pygame.draw.circle(surface, TEXT_PRIMARY_COLOR, handle_rect.center, handle_radius, 1) # Outline
    return handle_rect

# --- Screen Drawing Functions ---

def draw_menu():
    """Draws the improved main menu. Returns dict of button_name -> rect."""
    # Background
    draw_gradient_rect(WINDOW, WINDOW.get_rect(), (10, 0, 20), (30, 0, 60)) # Dark purple/blue gradient
    current_time = pygame.time.get_ticks()
    for i in range(40): # More subtle particles
        x = (current_time // 30 + i * 45 + math.sin(current_time * 0.0001 * i) * 50) % WIDTH
        y = (i * 20 + current_time // 70) % HEIGHT
        size = 1 + max(0, math.sin(current_time / 500 + i) * 1.5)
        alpha = 80 + math.sin(current_time / 350 + i * 2) * 40
        try: # Add alpha to color tuple, handle potential errors if color has alpha already
           base_particle_color = TEXT_SECONDARY_COLOR
           particle_color = base_particle_color + (int(max(0, min(255, alpha))),)
           pygame.draw.circle(WINDOW, particle_color, (x, y), size)
        except TypeError: # Fallback if color already has alpha
             pygame.draw.circle(WINDOW, base_particle_color, (x, y), size)


    # Title
    title_text = "Don't Get Eaten!"
    title_shadow_color = (0, 40, 80)
    for i in range(5, 0, -1): # Enhanced shadow/glow
        shadow_surf = menu_title_font.render(title_text, True, title_shadow_color)
        shadow_surf.set_alpha(max(0, 60 - i * 10))
        WINDOW.blit(shadow_surf, (WIDTH // 2 - shadow_surf.get_width() // 2 + i*2, HEIGHT // 4 - shadow_surf.get_height() // 2 + i*2))
    title_surf = menu_title_font.render(title_text, True, TITLE_COLOR)
    WINDOW.blit(title_surf, title_surf.get_rect(center=(WIDTH // 2, HEIGHT // 4)))

    # Buttons Layout
    button_width = 280; button_height = 65
    button_x = (WIDTH - button_width) // 2
    button_start_y = HEIGHT // 2 - 50; button_spacing = 85
    buttons_data = [ # Define button text and actions/states
        ("Play Game", "play"),
        ("Settings", "settings"),
        ("Quit", "quit")
    ]
    button_rects_map = {}
    for i, (text, action) in enumerate(buttons_data):
        rect = pygame.Rect(button_x, button_start_y + i * button_spacing, button_width, button_height)
        draw_styled_button(WINDOW, rect, text, menu_button_font, MENU_BUTTON_BASE, MENU_BUTTON_HOVER, MENU_TEXT_COLOR)
        button_rects_map[action] = rect # Store rect with action key

    # High Score
    if high_score > 0:
        hs_score_text = f"High Score: {high_score}"
        glow = abs(math.sin(current_time * 0.003)) * 55 + 200
        hs_score_surf = menu_hs_font.render(hs_score_text, True, (glow, glow // 1.5, 0))
        WINDOW.blit(hs_score_surf, hs_score_surf.get_rect(center=(WIDTH // 2, button_start_y + len(buttons_data) * button_spacing + 10)))

    return button_rects_map

def draw_pause_menu():
    """Draws the sidebar pause menu. Returns dict of button_name -> rect."""
    dim_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); dim_surface.fill(DIM_OVERLAY_COLOR); WINDOW.blit(dim_surface, (0, 0))
    panel_width = 300; panel_rect = pygame.Rect(0, 0, panel_width, HEIGHT)
    panel_surf = pygame.Surface(panel_rect.size, pygame.SRCALPHA); panel_surf.fill(PAUSE_PANEL_COLOR); WINDOW.blit(panel_surf, panel_rect.topleft)
    title_surf = pause_title_font.render("Paused", True, TITLE_COLOR); WINDOW.blit(title_surf, title_surf.get_rect(center=(panel_width // 2, 80)))
    button_width = 220; button_height = 55; button_x = (panel_width - button_width) // 2
    button_start_y = 180; button_spacing = 75
    buttons_data = [ # Define text and actions
        ("Resume", "resume"),
        ("Restart", "restart"),
        ("Settings", "settings"),
        ("Quit to Menu", "quit_menu")
    ]
    button_rects_map = {}
    for i, (text, action) in enumerate(buttons_data):
        rect = pygame.Rect(button_x, button_start_y + i * button_spacing, button_width, button_height)
        draw_styled_button(WINDOW, rect, text, pause_button_font, MENU_BUTTON_BASE, MENU_BUTTON_HOVER, MENU_TEXT_COLOR, radius=12, shadow_offset=2)
        button_rects_map[action] = rect
    return button_rects_map

def draw_settings_menu():
    """Draws the settings screen. Returns dict of interactive element rects."""
    global sfx_volume # To display current value
    # Background
    draw_gradient_rect(WINDOW, WINDOW.get_rect(), (20, 20, 30), (40, 40, 60))
    # Panel
    panel_width=500; panel_height=400; panel_x=(WIDTH-panel_width)//2; panel_y=(HEIGHT-panel_height)//2
    panel_rect = pygame.Rect(panel_x, panel_y, panel_width, panel_height)
    draw_rounded_rect(WINDOW, SETTINGS_PANEL_BG, panel_rect, 20)
    pygame.draw.rect(WINDOW, NEON_BLUE, panel_rect, 2, border_radius=20) # Border
    # Title
    title_surf = settings_title_font.render("Settings", True, TITLE_COLOR); WINDOW.blit(title_surf, title_surf.get_rect(center=(WIDTH // 2, panel_y + 60)))
    # Volume Slider
    volume_label_surf = settings_label_font.render("Sound FX Volume", True, TEXT_PRIMARY_COLOR); WINDOW.blit(volume_label_surf, volume_label_surf.get_rect(center=(WIDTH // 2, panel_y + 140)))
    slider_width = 300; slider_height = 15; slider_x = (WIDTH - slider_width) // 2; slider_y = panel_y + 180
    slider_rect = pygame.Rect(slider_x, slider_y, slider_width, slider_height)
    volume_handle_rect = draw_slider(WINDOW, slider_rect, sfx_volume, 0.0, 1.0, SLIDER_HANDLE_COLOR, SLIDER_BAR_COLOR, handle_radius=10)
    # Volume Value Text
    volume_text = f"{int(sfx_volume * 100)}%"; volume_value_surf = settings_value_font.render(volume_text, True, TEXT_PRIMARY_COLOR); WINDOW.blit(volume_value_surf, volume_value_surf.get_rect(center=(WIDTH // 2, slider_y + 35)))
    # Back Button
    back_button_rect = pygame.Rect(0, 0, 150, 55); back_button_rect.center = (WIDTH // 2, panel_y + panel_height - 60)
    draw_styled_button(WINDOW, back_button_rect, "Back", settings_back_button_font, MENU_BUTTON_BASE, MENU_BUTTON_HOVER, MENU_TEXT_COLOR, radius=15)
    # Return interactive elements
    return {"slider_rect": slider_rect, "volume_handle_rect": volume_handle_rect, "back_button_rect": back_button_rect}

# --- Gameplay Helper Functions ---

def trigger_screen_shake(duration_ms=150, intensity=4):
    # (Existing function - unchanged)
    start_time = pygame.time.get_ticks(); screen_copy = WINDOW.copy()
    while pygame.time.get_ticks() - start_time < duration_ms:
        offset_x = random.randint(-intensity, intensity); offset_y = random.randint(-intensity, intensity)
        WINDOW.blit(screen_copy, (offset_x, offset_y)); pygame.display.flip(); pygame.time.delay(15)

def display_game_over_screen():
    """Displays the game over screen and waits for input."""
    # --- Game Over Screen Display Logic ---
    # (Existing logic for drawing the 'Game Over' text, score, etc.)
    pygame.mixer.stop() # Stop game sounds
    loaded_sounds["game_over"].play()
    fade_surface = pygame.Surface((WIDTH, HEIGHT)); fade_surface.fill(BLACK)
    for alpha in range(0, 150, 5): # Fade in
        fade_surface.set_alpha(alpha); WINDOW.fill((10,10,20)); WINDOW.blit(fade_surface, (0, 0))
        pygame.display.flip(); pygame.time.delay(10)
    fade_surface.set_alpha(150); WINDOW.blit(fade_surface, (0,0)) # Ensure final overlay

    text = game_over_font.render('Game Over!', True, RED); final_score_text = f'Score: {player_score}'
    if player_score > 0 and player_score == high_score: final_score_text += " (New High Score!)"; score_color = GOLD
    else: score_color = WHITE
    score_text = game_over_score_font.render(final_score_text, True, score_color)
    text_rect = text.get_rect(center=(WIDTH//2, HEIGHT//2 - 50)); score_rect = score_text.get_rect(center=(WIDTH//2, HEIGHT//2 + 30))
    shadow_offset = 3; text_shadow = game_over_font.render('Game Over!', True, (50,0,0)); score_shadow = game_over_score_font.render(final_score_text, True, (30,30,30))

    continue_text_surf = continue_font.render('Press any key or click to continue', True, TEXT_PRIMARY_COLOR)
    continue_rect = continue_text_surf.get_rect(center=(WIDTH//2, HEIGHT//2 + 120))

    waiting = True; clock = pygame.time.Clock(); start_time = pygame.time.get_ticks()
    while waiting:
        current_ticks = pygame.time.get_ticks()
        for event in pygame.event.get(): # Need event loop here too
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            # Allow continue after short delay
            if (event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN) and current_ticks - start_time > 500:
                waiting = False

        # Redraw screen elements over the fade each frame
        WINDOW.blit(fade_surface, (0, 0))
        WINDOW.blit(text_shadow, (text_rect.x + shadow_offset, text_rect.y + shadow_offset)); WINDOW.blit(score_shadow, (score_rect.x + shadow_offset, score_rect.y + shadow_offset))
        WINDOW.blit(text, text_rect); WINDOW.blit(score_text, score_rect)
        # Pulsing "continue" text
        continue_alpha_surf = continue_text_surf.copy(); current_alpha = 128 + 127 * math.sin(current_ticks * 0.005)
        continue_alpha_surf.set_alpha(int(current_alpha)); WINDOW.blit(continue_alpha_surf, continue_rect)
        pygame.display.flip(); clock.tick(60)

def reset_game_state():
    """Resets all necessary variables for a new game."""
    global player_x, player_y, player_score, player_speed, snake_segments, snake_length
    global food_x, food_y, active_orbs, speed_boost_active, score_multiplier_active, paused
    global particles # Reset particles too

    player_score = 0
    player_x = WIDTH // 2
    player_y = HEIGHT // 2
    player_speed = player_base_speed
    snake_length = 3
    snake_segments = [(random.randint(100, WIDTH - 100), random.randint(100, HEIGHT - 100))]
    food_x = random.randint(50, WIDTH - 50)
    food_y = random.randint(50, HEIGHT - 50)
    active_orbs = []
    speed_boost_active = False
    score_multiplier_active = False
    paused = False
    particles = [] # Clear particles

# --- Main Application Loop ---
running = True
clock = pygame.time.Clock()
# Initial state is set before the loop (in_menu = True)

while running:
    # --- Event Handling (Common / State Transitions) ---
    mouse_pos = pygame.mouse.get_pos()
    events = pygame.event.get()

    for event in events:
        if event.type == pygame.QUIT:
            running = False
        # Handle slider drag release (common to settings state)
        if event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1 and dragging_slider:
                dragging_slider = False
                save_settings() # Save volume when drag ends
                if sfx_volume > 0.01 : loaded_sounds["volume_change"].play()

    # --- State Machine ---
    if in_menu:
        menu_buttons = draw_menu() # Draw and get button rects
        pygame.display.flip()

        for event in events: # Menu specific events
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if menu_buttons["play"].collidepoint(mouse_pos):
                    loaded_sounds["menu_click"].play(); in_menu = False; reset_game_state()
                elif menu_buttons["settings"].collidepoint(mouse_pos):
                    loaded_sounds["menu_click"].play(); in_menu = False; in_settings = True; settings_source = 'menu'
                elif menu_buttons["quit"].collidepoint(mouse_pos):
                    loaded_sounds["menu_click"].play(); running = False

    elif in_settings:
        interactive_elements = draw_settings_menu() # Draw and get interactive rects
        pygame.display.flip()

        slider_rect = interactive_elements["slider_rect"]
        handle_rect = interactive_elements["volume_handle_rect"]
        back_button_rect = interactive_elements["back_button_rect"]

        if dragging_slider: # Update volume if dragging
            relative_x = mouse_pos[0] - slider_rect.left
            sfx_volume = max(0.0, min(1.0, relative_x / slider_rect.width))
            apply_volume_to_sounds()

        for event in events: # Settings specific events
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: # ESC acts as Back
                loaded_sounds["menu_click"].play(); in_settings = False; save_settings()
                if settings_source == 'menu': in_menu = True
                elif settings_source == 'pause': paused = True
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if handle_rect.collidepoint(mouse_pos) or slider_rect.collidepoint(mouse_pos):
                    dragging_slider = True # Start dragging
                    # Update volume immediately on click
                    relative_x = mouse_pos[0] - slider_rect.left
                    sfx_volume = max(0.0, min(1.0, relative_x / slider_rect.width))
                    apply_volume_to_sounds()
                    if sfx_volume > 0.01: loaded_sounds["volume_change"].play() # Play feedback if not muted
                elif back_button_rect.collidepoint(mouse_pos):
                    loaded_sounds["menu_click"].play(); in_settings = False; save_settings()
                    if settings_source == 'menu': in_menu = True
                    elif settings_source == 'pause': paused = True

    elif paused: # In-Game Paused State
        pause_buttons = draw_pause_menu() # Draw and get button rects
        pygame.display.flip()

        for event in events: # Pause menu specific events
            if event.type == pygame.KEYDOWN and (event.key == pygame.K_ESCAPE or event.key == pygame.K_p):
                paused = False; loaded_sounds["pause"].play()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                action = None
                for act, rect in pause_buttons.items():
                    if rect.collidepoint(mouse_pos): action = act; break
                if action:
                    loaded_sounds["menu_click"].play()
                    if action == "resume": paused = False
                    elif action == "restart": reset_game_state(); paused = False # Reset and unpause
                    elif action == "settings": paused = False; in_settings = True; settings_source = 'pause'
                    elif action == "quit_menu": paused = False; in_menu = True

    else: # Active Gameplay State
        current_time = pygame.time.get_ticks() # Get time for gameplay logic
        # --- Handle Gameplay Input ---
        keys = pygame.key.get_pressed()
        moved = False
        # Player Movement
        if (keys[pygame.K_LEFT] or keys[pygame.K_a]) and player_x > 0: player_x -= player_speed; moved = True
        if (keys[pygame.K_RIGHT] or keys[pygame.K_d]) and player_x < WIDTH - PLAYER_SIZE: player_x += player_speed; moved = True
        if (keys[pygame.K_UP] or keys[pygame.K_w]) and player_y > 0: player_y -= player_speed; moved = True
        if (keys[pygame.K_DOWN] or keys[pygame.K_s]) and player_y < HEIGHT - PLAYER_SIZE: player_y += player_speed; moved = True
        # Pause Input
        for event in events:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                 paused = True; loaded_sounds["pause"].play()

        # --- Update Game Logic ---
        # Effect Management
        if speed_boost_active and current_time > speed_boost_end_time: speed_boost_active = False; player_speed = player_base_speed
        if score_multiplier_active and current_time > score_multiplier_end_time: score_multiplier_active = False
        # Snake Logic
        snake_current_speed = snake_base_speed + (player_score // 40) * 0.25
        head_x, head_y = snake_segments[0]; target_x, target_y = player_x, player_y
        dx = target_x - head_x; dy = target_y - head_y; dist = math.hypot(dx, dy)
        if dist > snake_current_speed: dx = dx / dist * snake_current_speed; dy = dy / dist * snake_current_speed; head_x += dx; head_y += dy
        elif dist > 0 : head_x, head_y = target_x, target_y
        snake_segments.insert(0, (head_x, head_y))
        target_length = 3 + player_score // 15
        while len(snake_segments) > target_length: snake_segments.pop()
        snake_length = len(snake_segments)
        # Collision Detection
        player_rect = pygame.Rect(player_x, player_y, PLAYER_SIZE, PLAYER_SIZE)
        game_over_condition = False
        if player_x <= 0 or player_x >= WIDTH-PLAYER_SIZE or player_y <= 0 or player_y >= HEIGHT-PLAYER_SIZE: game_over_condition = True
        else: # Check snake collision
            for i, segment in enumerate(snake_segments):
                if i > 1: # Ignore head/first segment
                    segment_rect = pygame.Rect(segment[0], segment[1], SNAKE_SIZE, SNAKE_SIZE)
                    if player_rect.colliderect(segment_rect.inflate(-SNAKE_SIZE * 0.4, -SNAKE_SIZE * 0.4)):
                        game_over_condition = True; break
        if game_over_condition:
            trigger_screen_shake(); high_score = max(high_score, player_score)
            display_game_over_screen(); in_menu = True; continue # Go to menu, skip rest of loop cycle
        # Food Collision
        food_rect = pygame.Rect(food_x, food_y, FOOD_SIZE, FOOD_SIZE)
        if player_rect.colliderect(food_rect):
            score_increase = 10*SCORE_MULTIPLIER_FACTOR if score_multiplier_active else 10; player_score += score_increase
            food_x=random.randint(50,WIDTH-50); food_y=random.randint(50,HEIGHT-50); loaded_sounds["collect_food"].play()
        # Orb Logic
        if random.random()<ORB_SPAWN_CHANCE and len(active_orbs)<3:
            orb_type=random.choice(['speed','score']); orb_x=random.randint(50,WIDTH-50); orb_y=random.randint(50,HEIGHT-50)
            active_orbs.append([orb_x,orb_y,orb_type,current_time])
        for orb in active_orbs[:]:
            orb_x,orb_y,orb_type,spawn_time=orb; orb_rect=pygame.Rect(orb_x,orb_y,ORB_SIZE,ORB_SIZE)
            if current_time-spawn_time>ORB_DESPAWN_TIME: active_orbs.remove(orb); continue
            if player_rect.colliderect(orb_rect):
                if orb_type=='speed': speed_boost_active=True; speed_boost_end_time=current_time+SPEED_BOOST_DURATION; player_speed=player_base_speed*SPEED_BOOST_FACTOR; loaded_sounds["collect_speed"].play()
                elif orb_type=='score': score_multiplier_active=True; score_multiplier_end_time=current_time+SCORE_MULTIPLIER_DURATION; loaded_sounds["collect_score"].play()
                active_orbs.remove(orb)
        # Particle Effects
        if moved and random.random()>0.4:
            p_color=NEON_BLUE;
            if speed_boost_active:p_color=(200,255,255)
            elif score_multiplier_active:p_color=(255,255,150)
            particles.append([player_x+PLAYER_SIZE//2+random.uniform(-5,5), player_y+PLAYER_SIZE//2+random.uniform(-5,5), random.randint(2,5), p_color, random.randint(15,25)])
        for particle in particles[:]:
            particle[2]-=0.15; particle[4]-=1
            if particle[2]<=0 or particle[4]<=0: particles.remove(particle)

        # --- Draw Active Game Screen ---
        WINDOW.fill((10, 10, 20));
        for x in range(0,WIDTH,40): # Grid background
             for y in range(0,HEIGHT,40): pygame.draw.rect(WINDOW,(20,20,30),(x,y,39,39))
        for particle in particles: pygame.draw.circle(WINDOW, particle[3], (int(particle[0]), int(particle[1])), int(particle[2])) # Particles
        for i, segment in enumerate(snake_segments): # Snake
            max_len=max(1,snake_length); intensity=max(55,255-(i*(200//max_len))); rect=pygame.Rect(segment[0],segment[1],SNAKE_SIZE,SNAKE_SIZE); color=(intensity,0,0)
            if i==0: glow_s=5+math.sin(current_time*0.01)*2; glow_c=(intensity//2,0,0); pygame.draw.circle(WINDOW,glow_c,rect.center,SNAKE_SIZE//2+glow_s)
            pygame.draw.rect(WINDOW,color,rect,border_radius=8)
            if i==0: # Eyes
                 eye_s=SNAKE_SIZE//6; eye_y=SNAKE_SIZE//3; eye_x1=SNAKE_SIZE//3; eye_x2=SNAKE_SIZE*2//3; px=0; py=0
                 if dist>0: px=dx/dist*(eye_s*0.4); py=dy/dist*(eye_s*0.4)
                 e1c=(segment[0]+eye_x1,segment[1]+eye_y); e2c=(segment[0]+eye_x2,segment[1]+eye_y)
                 pygame.draw.circle(WINDOW,WHITE,e1c,eye_s); pygame.draw.circle(WINDOW,WHITE,e2c,eye_s)
                 pygame.draw.circle(WINDOW,BLACK,(e1c[0]+px,e1c[1]+py),eye_s*0.5); pygame.draw.circle(WINDOW,BLACK,(e2c[0]+px,e2c[1]+py),eye_s*0.5)
        player_c=NEON_BLUE # Player
        if speed_boost_active: player_c = WHITE if (speed_boost_end_time-current_time)//100%2==0 else (150,220,255)
        player_o_c = GOLD if score_multiplier_active else (0,50,100)
        pygame.draw.rect(WINDOW,player_o_c,player_rect.inflate(6,6),border_radius=10); pygame.draw.rect(WINDOW,player_c,player_rect,border_radius=8)
        pulse=abs(math.sin(current_time*0.005))*3; food_c=(food_x+FOOD_SIZE//2,food_y+FOOD_SIZE//2) # Food
        pygame.draw.circle(WINDOW,(0,100,0),food_c,FOOD_SIZE+pulse+5); pygame.draw.circle(WINDOW,GREEN,food_c,FOOD_SIZE+pulse); pygame.draw.circle(WINDOW,(200,255,200),(food_c[0]-FOOD_SIZE//4,food_c[1]-FOOD_SIZE//4),FOOD_SIZE//4)
        for orb in active_orbs: # Orbs
             orb_x,orb_y,orb_t,spawn_t=orb; orb_p=abs(math.sin(current_time*0.008+spawn_t))*4; orb_c=(orb_x+ORB_SIZE//2,orb_y+ORB_SIZE//2)
             orb_col,glow_col = (LIGHT_BLUE,(0,0,100)) if orb_t=='speed' else (GOLD,(100,80,0))
             pygame.draw.circle(WINDOW,glow_col,orb_c,ORB_SIZE//2+orb_p+3); pygame.draw.circle(WINDOW,orb_col,orb_c,ORB_SIZE//2+orb_p)
             hl_c=tuple(min(255,c+100) for c in orb_col); pygame.draw.circle(WINDOW,hl_c,(orb_c[0]-ORB_SIZE//5,orb_c[1]-ORB_SIZE//5),ORB_SIZE//5)
        score_t=f'Score: {player_score}'; score_c=WHITE # Score & Timers
        if score_multiplier_active: score_t+=" x2!"; score_c=GOLD
        score_s=score_font.render(score_t,True,score_c); score_bg=pygame.Rect(10,5,score_s.get_width()+20,50); draw_rounded_rect(WINDOW,(0,0,0,150),score_bg,10); WINDOW.blit(score_s,(20,10))
        timer_y=score_bg.bottom+10; timer_h=10; timer_w=150; timer_bg=(50,50,50) # Timer Bars
        if speed_boost_active: rem=max(0,speed_boost_end_time-current_time); frac=rem/SPEED_BOOST_DURATION; cw=int(timer_w*frac); trb=pygame.Rect(10,timer_y,timer_w,timer_h); trf=pygame.Rect(10,timer_y,cw,timer_h); pygame.draw.rect(WINDOW,timer_bg,trb,border_radius=3); pygame.draw.rect(WINDOW,LIGHT_BLUE,trf,border_radius=3); tts=timer_font.render("Speed",True,WHITE); WINDOW.blit(tts,(trb.right+5,timer_y-2)); timer_y+=timer_h+5
        if score_multiplier_active: rem=max(0,score_multiplier_end_time-current_time); frac=rem/SCORE_MULTIPLIER_DURATION; cw=int(timer_w*frac); trb=pygame.Rect(10,timer_y,timer_w,timer_h); trf=pygame.Rect(10,timer_y,cw,timer_h); pygame.draw.rect(WINDOW,timer_bg,trb,border_radius=3); pygame.draw.rect(WINDOW,GOLD,trf,border_radius=3); tts=timer_font.render("Score x2",True,WHITE); WINDOW.blit(tts,(trb.right+5,timer_y-2))

        pygame.display.flip() # Update display for active game

    # --- Clock Tick ---
    clock.tick(60)

# --- Cleanup ---
pygame.quit()
sys.exit()